package com.example.spearmod;

import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1832;
import net.minecraft.class_243;

/**
 * Netherite spear. Charge damage, applied on hit while the attacker is
 * closing on the target, is:
 *   1.2 (netherite multiplier, from the Minecraft Wiki) x closing speed in blocks/s
 * with a 4.6 blocks/s minimum.
 */
public class SpearItem extends class_1829 {

    private static final double CHARGE_MIN_SPEED = 4.6;
    private static final float NETHERITE_CHARGE_MULTIPLIER = 1.2F;

    public SpearItem(class_1832 material, int attackDamage, float attackSpeed, class_1793 settings) {
        super(material, attackDamage, attackSpeed, settings);
    }

    @Override
    public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        boolean result = super.method_7873(stack, target, attacker);

        if (target.field_6002.field_9236 || !(attacker instanceof class_1657)) {
            return result;
        }

        class_243 toTarget = target.method_19538().method_1020(attacker.method_19538());
        if (toTarget.method_1033() < 1.0E-4) {
            return result;
        }
        class_243 dir = toTarget.method_1029();

        // Velocities are per tick; multiply by 20 for blocks per second.
        class_243 relative = attacker.method_18798().method_1020(target.method_18798());
        double closingSpeed = relative.method_1026(dir) * 20.0;

        if (closingSpeed >= CHARGE_MIN_SPEED) {
            float damage = (float) (NETHERITE_CHARGE_MULTIPLIER * closingSpeed);
            target.method_5643(class_1282.method_5532((class_1657) attacker), damage);
        }
        return result;
    }
}
