package com.example.spearmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1834;
import net.minecraft.class_1887;
import net.minecraft.class_2378;
import net.minecraft.class_2960;

public class SpearMod implements ModInitializer {

    public static final String MOD_ID = "spearmod";

    // Netherite spear: material damage 4 + 1 = 5 jab damage.
    public static final class_1792 NETHERITE_SPEAR = new SpearItem(
            class_1834.field_22033, 1, -2.8F,
            new class_1792.class_1793().method_7892(class_1761.field_7916).method_24359());

    public static final class_1887 LUNGE = new LungeEnchantment();

    @Override
    public void onInitialize() {
        class_2378.method_10230(class_2378.field_11142, new class_2960(MOD_ID, "netherite_spear"), NETHERITE_SPEAR);
        class_2378.method_10230(class_2378.field_11160, new class_2960(MOD_ID, "lunge"), LUNGE);

        // Lunge fires before the hit resolves, so a charge right after a lunge uses the new speed.
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (!world.field_9236) {
                LungeEnchantment.tryLunge(player, player.method_5998(hand), hand);
            }
            return class_1269.field_5811;
        });
    }
}
