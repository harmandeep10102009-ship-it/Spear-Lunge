package com.example.spearmod;

import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1886;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_243;

/**
 * Lunge III only, spear only. A landed jab pushes the player forward
 * by 1.37 blocks per tick (27.48 blocks per second). Costs 1 durability
 * and 12 exhaustion (4 x level 3). Does not trigger while riding or
 * gliding, or with food below 7 (outside creative).
 */
public class LungeEnchantment extends class_1887 {

    public static final int LEVEL = 3;
    private static final double IMPULSE = 1.37;

    public LungeEnchantment() {
        super(class_1887.class_1888.field_9090, class_1886.field_9074,
                new class_1304[]{class_1304.field_6173, class_1304.field_6171});
    }

    @Override
    public int method_8187() {
        return LEVEL;
    }

    @Override
    public int method_8183() {
        return LEVEL;
    }

    @Override
    public boolean method_8192(class_1799 stack) {
        return stack.method_7909() instanceof SpearItem;
    }

    public static void tryLunge(class_1657 player, class_1799 stack, class_1268 hand) {
        if (!(stack.method_7909() instanceof SpearItem)) {
            return;
        }
        if (class_1890.method_8225(SpearMod.LUNGE, stack) <= 0) {
            return;
        }
        if (player.method_5765() || player.method_6128()) {
            return;
        }
        if (!player.method_7337() && player.method_7344().method_7586() < 7) {
            return;
        }

        class_243 look = player.method_5720();
        class_243 horizontal = new class_243(look.field_1352, 0.0, look.field_1350);
        if (horizontal.method_1033() < 1.0E-4) {
            return;
        }
        class_243 dir = horizontal.method_1029();
        player.method_5762(dir.field_1352 * IMPULSE, 0.0, dir.field_1350 * IMPULSE);
        player.field_6037 = true;

        player.method_7322(4.0F * LEVEL);
        stack.method_7956(1, player, p -> p.method_20236(hand));
    }
}
